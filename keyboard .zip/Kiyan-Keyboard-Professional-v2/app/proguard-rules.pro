# Keep the Android input method service entry point.
-keep class com.kiyan.keyboard.KiyanIME { *; }
