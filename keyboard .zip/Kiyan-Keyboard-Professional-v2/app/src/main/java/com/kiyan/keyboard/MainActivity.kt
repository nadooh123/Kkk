package com.kiyan.keyboard

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.preference.PreferenceManager
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*

class MainActivity : Activity() {
    private val navy = Color.rgb(7, 21, 47)
    private val blue = Color.rgb(0, 145, 255)
    private val cyan = Color.rgb(0, 210, 230)
    private val purple = Color.rgb(130, 65, 245)
    private val prefs by lazy { getSharedPreferences("kiyan_settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        window.decorView.systemUiVisibility = 0
        buildDashboard()
    }

    private fun buildDashboard() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(245, 248, 255)) }
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(24)) }
        scroll.addView(page)
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(22), dp(22), dp(22), dp(22)); background = gradient(navy, Color.rgb(30, 60, 150), 26)
        }
        hero.addView(label("K  كيبورد كيان", 27f, Color.WHITE, true))
        hero.addView(label("لوحة مفاتيح ذكية • عربية وإنجليزية", 14f, Color.rgb(215,230,255), false).apply { setPadding(0,dp(8),0,dp(14)) })
        hero.addView(actionButton("تفعيل لوحة المفاتيح  ①", cyan) { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) })
        hero.addView(actionButton("اختيار كيبورد كيان  ②", blue) {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }.apply { setPadding(0, dp(8), 0, 0) })
        page.addView(hero, LinearLayout.LayoutParams(-1, -2))
        section(page, "التصميم والتخصيص")
        val grid = GridLayout(this).apply { columnCount = 2; useDefaultMargins = true }
        page.addView(grid)
        tile(grid, "🎨", "الثيمات", "ألوان كيان ومظهر داكن", purple) { showThemeDialog() }
        tile(grid, "⌨", "حجم اللوحة والخط", "ضبط الارتفاع وحجم الحروف", blue) { keyboardSizeDialog() }
        tile(grid, "🌐", "اللغات", "العربية والإنجليزية", Color.rgb(0,150,130)) { toast("تبديل اللغة متاح من لوحة المفاتيح") }
        tile(grid, "🔊", "الصوت والاهتزاز", "نغمات بيانو قصيرة", Color.rgb(220,40,140)) { showSoundDialog() }
        section(page, "الأدوات السريعة")
        val tools = GridLayout(this).apply { columnCount = 2; useDefaultMargins = true }
        page.addView(tools)
        tile(tools, "🧮", "الحاسبة", "حسابات سريعة", Color.rgb(155,35,190)) { calculatorDialog() }
        tile(tools, "📋", "ذاكرة النصوص", "حفظ نص لنسخه لاحقاً", Color.rgb(235,65,55)) { clipboardDialog() }
        tile(tools, "💬", "الاختصارات", "نصوص جاهزة", Color.rgb(225,30,100)) { shortcutsDialog() }
        tile(tools, "😊", "الإيموجي", "رموز شائعة", Color.rgb(70,190,35)) { emojiDialog() }
        val note = label("كيان — تجربة كتابة مصممة لتكون بسيطة وسريعة", 13f, Color.DKGRAY, false)
        note.gravity = Gravity.CENTER
        note.setPadding(0, dp(22), 0, 0)
        page.addView(note)
        setContentView(scroll)
    }

    private fun section(parent: LinearLayout, text: String) {
        parent.addView(label(text, 20f, Color.rgb(25,35,65), true).apply { setPadding(dp(2), dp(22), 0, dp(8)) })
    }
    private fun tile(parent: GridLayout, emoji: String, title: String, subtitle: String, color: Int, click: () -> Unit) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(12), dp(16), dp(12), dp(16))
            background = rounded(Color.WHITE, 20, Color.rgb(226,232,246), 1)
            elevation = dp(3).toFloat(); isClickable = true; isFocusable = true; setOnClickListener { click() }
        }
        card.addView(label(emoji, 28f, color, true).apply { gravity = Gravity.CENTER })
        card.addView(label(title, 17f, Color.rgb(25,35,65), true).apply { gravity = Gravity.CENTER; setPadding(0,dp(7),0,dp(3)) })
        card.addView(label(subtitle, 11f, Color.GRAY, false).apply { gravity = Gravity.CENTER })
        val lp = GridLayout.LayoutParams().apply { width = 0; height = dp(128); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(dp(4),dp(4),dp(4),dp(4)) }
        parent.addView(card, lp)
    }
    private fun actionButton(text: String, color: Int, click: () -> Unit) = TextView(this).apply {
        this.text = text; textSize = 16f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setPadding(dp(12),dp(12),dp(12),dp(12))
        background = rounded(color, 14); isClickable = true; isFocusable = true; setOnClickListener { click() }
    }
    private fun label(text: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        textDirection = View.TEXT_DIRECTION_FIRST_STRONG
    }
    private fun rounded(color: Int, radius: Int, stroke: Int? = null, width: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); if (stroke != null) setStroke(dp(width), stroke)
    }
    private fun gradient(a: Int, b: Int, radius: Int) = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(a,b)).apply { cornerRadius = dp(radius).toFloat() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()

    private fun showThemeDialog() {
        val themes = arrayOf("كيان الأزرق", "سماوي", "بنفسجي داكن", "فاتح")
        android.app.AlertDialog.Builder(this).setTitle("اختر المظهر").setItems(themes) { _, which ->
            prefs.edit().putInt("theme_choice", which).apply(); toast("تم حفظ اختيارك: ${themes[which]}. سيُطبّق على عناصر التطبيق المدعومة.")
        }.show()
    }
    private fun showSoundDialog() {
        val enabled = prefs.getBoolean("kiyan_piano_enabled", false)
        val check = CheckBox(this).apply { text = "تفعيل نغمات البيانو عند الكتابة"; isChecked = enabled; setPadding(dp(18),dp(12),dp(18),dp(12)) }
        val seek = SeekBar(this).apply { max = 100; progress = prefs.getInt("kiyan_piano_volume",65) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(check); addView(label("مستوى الصوت",14f,Color.DKGRAY,false).apply { setPadding(dp(18),dp(8),dp(18),0) }); addView(seek) }
        android.app.AlertDialog.Builder(this).setTitle("الصوت والاهتزاز").setView(box)
            .setPositiveButton("حفظ") { _, _ -> prefs.edit().putBoolean("kiyan_piano_enabled",check.isChecked).putInt("kiyan_piano_volume",seek.progress).apply(); PreferenceManager.getDefaultSharedPreferences(this).edit().putBoolean("kiyan_piano_enabled",check.isChecked).putInt("kiyan_piano_volume",seek.progress).apply(); toast("تم حفظ إعدادات الصوت") }
            .setNegativeButton("إلغاء",null).show()
    }
    private fun calculatorDialog() {
        val input = EditText(this).apply { hint = "مثال: 12*8+5"; inputType = 8194 }
        android.app.AlertDialog.Builder(this).setTitle("حاسبة كيان").setView(input).setPositiveButton("احسب") { _, _ ->
            try { val expr = input.text.toString().replace(" ", ""); val result = SimpleCalculator.eval(expr); toast("النتيجة: $result") }
            catch (_: Exception) { toast("تحقق من العملية الحسابية") }
        }.setNegativeButton("إغلاق",null).show()
    }
    private fun clipboardDialog() {
        val input = EditText(this).apply { hint = "اكتب نصاً لحفظه"; minLines = 2 }
        android.app.AlertDialog.Builder(this).setTitle("ذاكرة النصوص").setView(input).setPositiveButton("حفظ") { _, _ -> prefs.edit().putString("saved_clip",input.text.toString()).apply(); toast("تم حفظ النص على هذا الجهاز") }
            .setNeutralButton("نسخ المحفوظ") { _, _ -> val value = prefs.getString("saved_clip","").orEmpty(); if(value.isNotEmpty()){ val cm=getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager; cm.setPrimaryClip(android.content.ClipData.newPlainText("Kiyan",value)); toast("تم النسخ") } else toast("لا يوجد نص محفوظ") }.show()
    }
    private fun shortcutsDialog() {
        val defaults = listOf("السلام عليكم ورحمة الله وبركاته", "شكراً لك", "سأرد عليك لاحقاً", "إن شاء الله")
        val items = prefs.getString("keyboard_shortcuts", null)?.split("\n")?.filter { it.isNotBlank() } ?: defaults
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), dp(4)) }
        val editor = EditText(this).apply { hint = "كل اختصار في سطر مستقل"; minLines = 4; setText(items.joinToString("\n")) }
        box.addView(editor)
        android.app.AlertDialog.Builder(this).setTitle("اختصارات كيان") .setMessage("عدّل العبارات التي تريد ظهورها في شريط الاختصارات.") .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val value = editor.text.toString().lines().map { it.trim() }.filter { it.isNotEmpty() }.distinct().take(30).joinToString("\n")
                prefs.edit().putString("keyboard_shortcuts", value).apply(); toast("تم حفظ الاختصارات")
            }.setNeutralButton("نسخ عبارة افتراضية") { _, _ ->
                val cm=getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("Kiyan shortcut", defaults.first())); toast("تم نسخ العبارة")
            }.setNegativeButton("إغلاق", null).show()
    }

    private fun keyboardSizeDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), dp(4)) }
        fun addControl(labelText: String, key: String, min: Int, max: Int, default: Int, suffix: String) {
            box.addView(TextView(this).apply { text = labelText; textSize = 15f; setTextColor(Color.DKGRAY) })
            val seek = SeekBar(this).apply {
                this.max = max - min
                progress = (prefs.getInt(key, default) - min).coerceIn(0, max - min)
            }
            val value = TextView(this).apply { text = "${seek.progress + min}$suffix"; setTextColor(Color.DKGRAY) }
            seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    val v = progress + min; value.text = "$v$suffix"; prefs.edit().putInt(key, v).apply()
                    PreferenceManager.getDefaultSharedPreferences(this@MainActivity).edit().putInt(key, v).apply()
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
            box.addView(value); box.addView(seek)
        }
        addControl("ارتفاع لوحة المفاتيح", "keyboard_height", 180, 360, 260, " dp")
        addControl("حجم الحروف", "keyboard_font_size", 12, 28, 16, "")
        android.app.AlertDialog.Builder(this).setTitle("حجم اللوحة والخط").setView(box)
            .setPositiveButton("تم") { _, _ -> toast("حُفظت الإعدادات؛ أعد فتح لوحة المفاتيح لتطبيق الارتفاع") }
            .setNegativeButton("إغلاق", null).show()
    }

    private fun emojiDialog() {
        val items = arrayOf("😊", "😂", "❤️", "👍", "🙏", "✨", "🥰", "😎", "🎉", "🔥", "💙", "🌹", "😭", "😍", "🤔", "👏")
        android.app.AlertDialog.Builder(this).setTitle("إيموجي كيان").setItems(items) { _, i ->
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("Kiyan emoji", items[i])); toast("نُسخ ${items[i]} — الصقه في حقل الكتابة")
        }.show()
    }
}

private object SimpleCalculator {
    fun eval(source: String): Double = Parser(source).parse()
    private class Parser(private val source: String) {
        private val tokens = Regex("\\d+(?:\\.\\d+)?|[()+*/-]").findAll(source).map { it.value }.toList()
        private var pos = 0
        fun parse(): Double { require(tokens.joinToString("") == source && tokens.isNotEmpty()); val v = expression(); require(pos == tokens.size); return v }
        private fun expression(): Double { var v=term(); while(pos<tokens.size && (tokens[pos]=="+" || tokens[pos]=="-")){ val op=tokens[pos++]; val n=term(); v=if(op=="+") v+n else v-n }; return v }
        private fun term(): Double { var v=factor(); while(pos<tokens.size && (tokens[pos]=="*" || tokens[pos]=="/")){ val op=tokens[pos++]; val n=factor(); require(op!="/" || n!=0.0); v=if(op=="*") v*n else v/n }; return v }
        private fun factor(): Double { if(pos<tokens.size && tokens[pos]=="-"){pos++; return -factor()}; if(pos<tokens.size && tokens[pos]=="("){pos++; val v=expression(); require(pos<tokens.size && tokens[pos++]==")"); return v}; return tokens[pos++].toDouble() }
    }
}
