package com.kiyan.keyboard

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.preference.PreferenceManager

/** Low-latency key sounds. Enable with preference kiyan_piano_enabled=true. */
class PianoSoundManager(context: Context) {
    private val prefs = PreferenceManager.getDefaultSharedPreferences(context)
    private val pool = SoundPool.Builder()
        .setMaxStreams(10)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        ).build()
    private val rawNotes = intArrayOf(
        R.raw.piano_c4, R.raw.piano_d4, R.raw.piano_e4, R.raw.piano_f4,
        R.raw.piano_g4, R.raw.piano_a4, R.raw.piano_b4, R.raw.piano_c5
    )
    private val soundIds = IntArray(rawNotes.size)
    @Volatile private var loadedCount = 0
    @Volatile private var released = false

    init {
        pool.setOnLoadCompleteListener { _, sampleId, status ->
            if (status == 0 && soundIds.contains(sampleId)) {
                loadedCount = (loadedCount + 1).coerceAtMost(soundIds.size)
            }
        }
        rawNotes.forEachIndexed { index, resource -> soundIds[index] = pool.load(context, resource, 1) }
    }

    fun playPianoNote(char: Char) {
        if (released || !prefs.getBoolean("kiyan_piano_enabled", false) || loadedCount < soundIds.size) return
        val volume = (prefs.getInt("kiyan_piano_volume", 65).coerceIn(0, 100) / 100f)
        val index = when {
            char.isLetter() -> (char.lowercaseChar().code - 'a'.code).coerceAtLeast(0) % soundIds.size
            char.isDigit() -> (char.code - '0'.code) % soundIds.size
            char.isWhitespace() -> 0
            else -> char.code % soundIds.size
        }
        pool.play(soundIds[index], volume, volume, 1, 0, 1f)
    }

    fun release() {
        if (!released) {
            released = true
            pool.setOnLoadCompleteListener(null)
            pool.release()
        }
    }
}
