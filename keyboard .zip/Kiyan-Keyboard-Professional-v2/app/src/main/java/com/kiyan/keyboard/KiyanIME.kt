package com.kiyan.keyboard

import android.inputmethodservice.InputMethodService
import android.view.LayoutInflater
import android.view.View
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.content.Context
import android.preference.PreferenceManager
import android.widget.Button
import android.widget.LinearLayout
import android.view.inputmethod.InputConnection

/** IME example: commits text normally, then optionally plays a short piano note. */
class KiyanIME : InputMethodService() {
    private lateinit var pianoSoundManager: PianoSoundManager
    // The XML initially displays QWERTY English labels, so keep mode in sync.
    private var arabicMode = false
    private var symbolsMode = false

    override fun onCreate() {
        super.onCreate()
        pianoSoundManager = PianoSoundManager(this)
    }

    override fun onCreateInputView(): View {
        val view = layoutInflater.inflate(R.layout.keyboard_view, null)
        val settings = getSharedPreferences("kiyan_settings", MODE_PRIVATE)
        val savedHeight = settings.getInt("keyboard_height", 260)
        arabicMode = settings.getBoolean("arabic_mode", false)
        view.layoutParams = android.view.ViewGroup.LayoutParams(
            android.view.ViewGroup.LayoutParams.MATCH_PARENT,
            (savedHeight * resources.displayMetrics.density).toInt()
        )
        styleKeyboard(view)
        bindKeyboard(view)
        applyLanguage(view, arabicMode)
        return view
    }

    private fun bindKeyboard(root: View) {
        val keyIds = intArrayOf(
            R.id.key_q, R.id.key_w, R.id.key_e, R.id.key_r, R.id.key_t,
            R.id.key_y, R.id.key_u, R.id.key_i, R.id.key_o, R.id.key_p,
            R.id.key_a, R.id.key_s, R.id.key_d, R.id.key_f, R.id.key_g,
            R.id.key_h, R.id.key_j, R.id.key_k, R.id.key_l,
            R.id.key_z, R.id.key_x, R.id.key_c, R.id.key_v, R.id.key_b,
            R.id.key_n, R.id.key_m, R.id.key_space, R.id.key_delete, R.id.key_enter
        )
        keyIds.forEach { id ->
            root.findViewById<Button>(id)?.setOnClickListener { button ->
                val tag = button.tag?.toString().orEmpty()
                when (tag) {
                    "DELETE" -> { currentInputConnection?.deleteSurroundingText(1, 0); if (PreferenceManager.getDefaultSharedPreferences(this).getBoolean("kiyan_piano_enabled", false)) pianoSoundManager.playPianoNote('\b') }
                    "ENTER" -> {
                        val connection = currentInputConnection
                        val action = currentInputEditorInfo?.imeOptions?.and(android.view.inputmethod.EditorInfo.IME_MASK_ACTION) ?: android.view.inputmethod.EditorInfo.IME_ACTION_NONE
                        val handled = when (action) {
                            android.view.inputmethod.EditorInfo.IME_ACTION_GO,
                            android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH,
                            android.view.inputmethod.EditorInfo.IME_ACTION_SEND,
                            android.view.inputmethod.EditorInfo.IME_ACTION_NEXT,
                            android.view.inputmethod.EditorInfo.IME_ACTION_DONE,
                            android.view.inputmethod.EditorInfo.IME_ACTION_PREVIOUS -> connection?.performEditorAction(action) == true
                            else -> false
                        }
                        if (!handled) {
                            connection?.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_ENTER))
                            connection?.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, android.view.KeyEvent.KEYCODE_ENTER))
                        }
                        pianoSoundManager.playPianoNote('\n')
                    }
                    "SPACE" -> onKeyPress(android.view.KeyEvent.KEYCODE_SPACE, ' ')
                    else -> tag.firstOrNull()?.let { onKeyPress(it.code, it) }
                }
            }
        }
        // Number row has no dedicated IDs, so bind its tagged buttons separately.
        for (i in 0..9) root.findViewWithTag<Button>(i.toString())?.setOnClickListener { onKeyPress(i, ('0'.code + i).toChar()) }
        root.findViewById<Button>(R.id.key_language)?.setOnClickListener { toggleLanguage(root) }
        root.findViewById<Button>(R.id.key_symbols)?.setOnClickListener { toggleSymbols(root) }
        listOf(R.id.suggestion_1, R.id.suggestion_2, R.id.suggestion_3).forEach { id ->
            root.findViewById<Button>(id)?.setOnClickListener { button ->
                val suggestion = (button as Button).text?.toString().orEmpty()
                if (suggestion.isNotBlank() && suggestion != "😊") {
                    val before = currentInputConnection?.getTextBeforeCursor(100, 0)?.toString().orEmpty()
                    val currentWord = before.takeLastWhile { !it.isWhitespace() }
                    if (currentWord.isNotEmpty()) currentInputConnection?.deleteSurroundingText(currentWord.length, 0)
                    currentInputConnection?.commitText(suggestion, 1)
                    updateSuggestions(root)
                } else if (suggestion == "😊") showEmojiPicker(root)
            }
        }
        updateSuggestions(root)
        root.findViewById<Button>(R.id.tool_emoji)?.setOnClickListener { showEmojiPicker(root) }
        root.findViewById<Button>(R.id.tool_emoji_art)?.setOnClickListener { showInlineChoices(root, "رسوم إيموجي", listOf("(｡♥‿♥｡)", "¯\\_(ツ)_/¯", "(づ｡◕‿‿◕｡)づ", "(ง'̀-'́)ง")) }
        root.findViewById<Button>(R.id.tool_templates)?.setOnClickListener { showInlineChoices(root, "قوالب النصوص", listOf("السلام عليكم ورحمة الله وبركاته", "شكراً لك", "سأعود إليك لاحقاً", "تم استلام رسالتك")) }
        root.findViewById<Button>(R.id.tool_shortcuts)?.setOnClickListener { showShortcutsPanel(root) }
        root.findViewById<Button>(R.id.tool_calculator)?.setOnClickListener { showCalculator() }
        root.findViewById<Button>(R.id.tool_drawer)?.setOnClickListener { showToolsDrawer(root) }
        root.findViewById<Button>(R.id.tool_resize)?.setOnClickListener { showResizePanel(root) }
        root.findViewById<Button>(R.id.tool_suggestions)?.setOnClickListener {
            val before = currentInputConnection?.getTextBeforeCursor(80, 0)?.toString().orEmpty()
            val word = before.takeLastWhile { !it.isWhitespace() }
            val suggestions = when (word) {
                "سلا", "سلام" -> "السلام عليكم"
                "مر" , "مرح" -> "مرحبا"
                "شك", "شكر" -> "شكراً لك"
                "th", "tha" -> "thanks"
                "hel", "hell" -> "hello"
                else -> if (arabicMode) "مرحبا" else "hello"
            }
            currentInputConnection?.commitText(suggestions, 1)
        }
        root.findViewById<Button>(R.id.tool_gif)?.setOnClickListener { openGifSearch() }
        root.findViewById<Button>(R.id.tool_search)?.setOnClickListener {
            val intent = android.content.Intent(android.content.Intent.ACTION_WEB_SEARCH).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            try { startActivity(intent) } catch (_: Exception) { toast("البحث غير متاح على هذا الجهاز") }
        }
        root.findViewById<Button>(R.id.tool_settings)?.setOnClickListener {
            val intent = packageManager.getLaunchIntentForPackage(packageName)?.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            if (intent != null) startActivity(intent) else toast("افتح تطبيق كيبورد كيان للإعدادات")
        }
    }

    private fun toggleLanguage(root: View) {
        arabicMode = !arabicMode
        symbolsMode = false
        getSharedPreferences("kiyan_settings", MODE_PRIVATE).edit().putBoolean("arabic_mode", arabicMode).apply()
        applyLanguage(root, arabicMode)
    }

    private fun applyLanguage(root: View, arabic: Boolean) {
        val ids = intArrayOf(R.id.key_q,R.id.key_w,R.id.key_e,R.id.key_r,R.id.key_t,R.id.key_y,R.id.key_u,R.id.key_i,R.id.key_o,R.id.key_p,
            R.id.key_a,R.id.key_s,R.id.key_d,R.id.key_f,R.id.key_g,R.id.key_h,R.id.key_j,R.id.key_k,R.id.key_l,
            R.id.key_z,R.id.key_x,R.id.key_c,R.id.key_v,R.id.key_b,R.id.key_n,R.id.key_m)
        val english = "qwertyuiopasdfghjklzxcvbnm"
        // The current XML has 26 letter keys; keep the mapping aligned with those keys.
        val arabicLetters = "ضصثقفغعهخحجشسيبلاتنمكطئءؤرى"
        ids.forEachIndexed { index, id ->
            val button = root.findViewById<Button>(id) ?: return@forEachIndexed
            val ch = if (arabic) arabicLetters.getOrNull(index) ?: english[index] else english[index]
            button.text = ch.toString().uppercase()
            button.tag = ch.toString()
        }
        root.findViewById<Button>(R.id.key_space)?.text = if (arabic) "العربية" else "English"
        root.findViewById<Button>(R.id.key_symbols)?.text = "123"
    }

    private fun toggleSymbols(root: View) {
        symbolsMode = !symbolsMode
        val ids = intArrayOf(R.id.key_q,R.id.key_w,R.id.key_e,R.id.key_r,R.id.key_t,R.id.key_y,R.id.key_u,R.id.key_i,R.id.key_o,R.id.key_p,
            R.id.key_a,R.id.key_s,R.id.key_d,R.id.key_f,R.id.key_g,R.id.key_h,R.id.key_j,R.id.key_k,R.id.key_l,
            R.id.key_z,R.id.key_x,R.id.key_c,R.id.key_v,R.id.key_b,R.id.key_n,R.id.key_m)
        val english = "qwertyuiopasdfghjklzxcvbnm"
        val arabic = "ضصثقفغعهخحجشسيبلاتنمكطئءؤرىةوزظ"
        val symbols = "1234567890@#%&-+!?=/:;()[]{}"
        ids.forEachIndexed { index, id ->
            val button = root.findViewById<Button>(id)
            val ch = if (symbolsMode) symbols.getOrNull(index) ?: '·' else if (arabicMode) arabic.getOrNull(index) ?: english[index] else english[index]
            button.text = ch.toString().uppercase()
            button.tag = ch.toString()
        }
        root.findViewById<Button>(R.id.key_symbols)?.text = if (symbolsMode) "ABC" else "123"
    }

    private fun styleKeyboard(root: View) {
        val prefs = PreferenceManager.getDefaultSharedPreferences(this)
        val palette = when (getSharedPreferences("kiyan_settings", Context.MODE_PRIVATE).getInt("theme_choice", 0)) {
            1 -> intArrayOf(Color.rgb(0, 42, 57), Color.rgb(0, 188, 212), Color.rgb(0, 229, 255))
            2 -> intArrayOf(Color.rgb(24, 10, 45), Color.rgb(105, 45, 220), Color.rgb(191, 90, 255))
            3 -> intArrayOf(Color.rgb(238, 243, 250), Color.WHITE, Color.rgb(0, 130, 220))
            else -> intArrayOf(Color.rgb(7, 18, 43), Color.rgb(15, 42, 85), Color.rgb(0, 174, 255))
        }
        root.setBackgroundColor(palette[0])
        val buttons = ArrayList<Button>()
        fun collect(view: View) {
            if (view is Button) buttons.add(view)
            if (view is android.view.ViewGroup) for (i in 0 until view.childCount) collect(view.getChildAt(i))
        }
        collect(root)
        buttons.forEach { b ->
            val isTool = b.id == R.id.tool_emoji || b.id == R.id.tool_suggestions || b.id == R.id.tool_gif || b.id == R.id.tool_search || b.id == R.id.tool_settings || b.id == R.id.tool_resize || b.id == R.id.tool_drawer || b.id == R.id.tool_calculator || b.id == R.id.tool_shortcuts || b.id == R.id.tool_templates || b.id == R.id.tool_emoji_art
            val special = b.id == R.id.key_enter || b.id == R.id.key_symbols || b.id == R.id.key_language || b.id == R.id.tool_settings || b.id == R.id.tool_resize || b.id == R.id.tool_drawer
            val bg = if (special) palette[2] else if (palette[0] == Color.rgb(238, 243, 250)) Color.WHITE else palette[1]
            b.background = GradientDrawable().apply {
                setColor(if (isTool) palette[2] else bg)
                cornerRadius = (if (isTool) 20f else 10f) * resources.displayMetrics.density
                if (!special && !isTool) setStroke((resources.displayMetrics.density).toInt().coerceAtLeast(1), if (palette[0] == Color.rgb(238, 243, 250)) Color.LTGRAY else Color.rgb(35, 83, 145))
            }
            b.setTextColor(if (palette[0] == Color.rgb(238, 243, 250)) Color.rgb(25, 45, 80) else Color.WHITE)
            b.textSize = if (b.id == R.id.tool_suggestions) 13f else prefs.getInt("keyboard_font_size", 16).toFloat()
            b.isAllCaps = false
            b.elevation = (if (isTool) 3f else 1.5f) * resources.displayMetrics.density
            b.setPadding(2, 0, 2, 0)
        }
    }



    private fun showToolsDrawer(root: View) {
        val items = arrayOf("🧮 الحاسبة", "★ الاختصارات", "📋 قوالب النصوص", "📎 النص المحفوظ", "😊 الإيموجي", "✿ Emoji Art", "GIF والبحث عن الصور", "⌕ البحث", "↕ تغيير الحجم", "✂ تحرير النص", "Aa حجم الخط")
        android.app.AlertDialog.Builder(this)
            .setTitle("أدوات كيان السريعة")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> showCalculator()
                    1 -> showInlineChoices(root, "الاختصارات", listOf("السلام عليكم", "شكراً لك", "سأرد عليك لاحقاً", "إن شاء الله"))
                    2 -> showInlineChoices(root, "قوالب النصوص", listOf("السلام عليكم ورحمة الله وبركاته", "شكراً لك", "سأعود إليك لاحقاً", "تم استلام رسالتك"))
                    3 -> pasteSavedText()
                    4 -> showEmojiPicker(root)
                    5 -> showInlineChoices(root, "رسوم إيموجي", listOf("(｡♥‿♥｡)", "¯\\_(ツ)_/¯", "(づ｡◕‿‿◕｡)づ", "(ง'̀-'́)ง"))
                    6 -> openGifSearch()
                    7 -> { try { startActivity(android.content.Intent(android.content.Intent.ACTION_WEB_SEARCH).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { toast("البحث غير متاح على هذا الجهاز") } }
                    8 -> showResizePanel(root)
                    9 -> showEditingPanel(root)
                    10 -> showFontSizePanel(root)
                }
            }.setNegativeButton("إغلاق", null).show()
    }

    private fun showShortcutsPanel(root: View) {
        val saved = getSharedPreferences("kiyan_settings", MODE_PRIVATE)
        val defaults = listOf("السلام عليكم ورحمة الله وبركاته", "شكراً لك", "سأرد عليك لاحقاً", "إن شاء الله")
        val custom = saved.getString("keyboard_shortcuts", null)?.split("\n")?.filter { it.isNotBlank() }
        showInlineChoices(root, "اختصارات كيان — اضغط لإدراج النص", custom?.takeIf { it.isNotEmpty() } ?: defaults)
    }

    private fun pasteSavedText() {
        val value = getSharedPreferences("kiyan_settings", MODE_PRIVATE).getString("saved_clip", "").orEmpty()
        if (value.isNotBlank()) currentInputConnection?.commitText(value, 1) else toast("لا يوجد نص محفوظ. احفظ نصاً من تطبيق كيان أولاً")
    }

    private fun openGifSearch() {
        val intent = android.content.Intent(android.content.Intent.ACTION_WEB_SEARCH)
            .putExtra(android.app.SearchManager.QUERY, "GIF متحركة")
            .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(intent) } catch (_: Exception) { toast("تعذر فتح البحث عن GIF على هذا الجهاز") }
    }

    private fun showEmojiPicker(root: View) {
        val input = android.widget.EditText(this).apply { hint = "ابحث باسم الإيموجي أو اختر رمزاً"; singleLine = true }
        val emojis = listOf("😊", "😂", "❤️", "👍", "🙏", "✨", "🥰", "😎", "🎉", "🔥", "💙", "🌹", "😭", "😍", "🤔", "👏")
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 8, 16, 4); addView(input) }
        val grid = android.widget.GridLayout(this).apply { columnCount = 4 }
        fun populate(query: String) {
            grid.removeAllViews()
            emojis.filter { query.isBlank() || it.contains(query) }.forEach { emoji ->
                grid.addView(Button(this).apply { text = emoji; textSize = 24f; setOnClickListener { currentInputConnection?.commitText(emoji, 1) } }, android.widget.GridLayout.LayoutParams().apply { width = 0; columnSpec = android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED, 1f) })
            }
        }
        populate("")
        input.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { populate(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        box.addView(android.widget.ScrollView(this).apply { addView(grid) }, LinearLayout.LayoutParams(-1, (180 * resources.displayMetrics.density).toInt()))
        android.app.AlertDialog.Builder(this).setTitle("الإيموجي") .setView(box).setNegativeButton("تم", null).show()
    }

    private fun showFontSizePanel(root: View) {
        val parent = root as? LinearLayout ?: return
        parent.findViewWithTag<View>("kiyan_inline_panel")?.let { parent.removeView(it) }
        val panel = LinearLayout(this).apply { tag = "kiyan_inline_panel"; orientation = LinearLayout.VERTICAL; setPadding(10, 6, 10, 6); setBackgroundColor(Color.rgb(20, 55, 105)) }
        panel.addView(android.widget.TextView(this).apply { text = "حجم خط المفاتيح"; setTextColor(Color.WHITE); gravity = android.view.Gravity.CENTER })
        val seek = android.widget.SeekBar(this).apply {
            max = 16
            progress = (getSharedPreferences("kiyan_settings", MODE_PRIVATE).getInt("keyboard_font_size", 16) - 12).coerceIn(0, 16)
            setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: android.widget.SeekBar?, value: Int, fromUser: Boolean) {
                    val size = value + 12
                    getSharedPreferences("kiyan_settings", MODE_PRIVATE).edit().putInt("keyboard_font_size", size).apply()
                    fun update(v: View) { if (v is Button && v.id !in listOf(R.id.tool_settings, R.id.tool_search)) v.textSize = size.toFloat(); if (v is android.view.ViewGroup) for (i in 0 until v.childCount) update(v.getChildAt(i)) }
                    update(root)
                }
                override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}
                override fun onStopTrackingTouch(sb: android.widget.SeekBar?) {}
            })
        }
        panel.addView(seek)
        parent.addView(panel, 1)
    }

    private fun showInlineChoices(root: View, title: String, choices: List<String>) {
        val parent = root as? LinearLayout ?: return
        parent.findViewWithTag<View>("kiyan_inline_panel")?.let { parent.removeView(it) }
        val panel = LinearLayout(this).apply {
            tag = "kiyan_inline_panel"; orientation = LinearLayout.VERTICAL
            setPadding(8, 6, 8, 6); setBackgroundColor(Color.rgb(20, 55, 105))
        }
        panel.addView(android.widget.TextView(this).apply { text = title; textSize = 15f; setTextColor(Color.WHITE); gravity = android.view.Gravity.CENTER })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        choices.forEach { choice ->
            val b = Button(this).apply { text = choice; textSize = 12f; isAllCaps = false; setOnClickListener {
                if (choice.contains("بحث الويب")) {
                    try { startActivity(android.content.Intent(android.content.Intent.ACTION_WEB_SEARCH).putExtra(android.app.SearchManager.QUERY, "GIF").addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    catch (_: Exception) { toast("البحث غير متاح على هذا الجهاز") }
                }
                else if (choice.contains("حجم") || choice.contains("تغيير")) showResizePanel(root)
                else if (choice.contains("تحرير")) showEditingPanel(root)
                else currentInputConnection?.commitText(choice, 1)
            } }
            row.addView(b, LinearLayout.LayoutParams(0, (42 * resources.displayMetrics.density).toInt(), 1f))
        }
        panel.addView(android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })
        parent.addView(panel, 1)
    }

    private fun showResizePanel(root: View) {
        val parent = root as? LinearLayout ?: return
        parent.findViewWithTag<View>("kiyan_inline_panel")?.let { parent.removeView(it) }
        val panel = LinearLayout(this).apply { tag = "kiyan_inline_panel"; orientation = LinearLayout.VERTICAL; setPadding(10, 4, 10, 4); setBackgroundColor(Color.rgb(20, 55, 105)) }
        panel.addView(android.widget.TextView(this).apply { text = "تخصيص حجم لوحة المفاتيح"; setTextColor(Color.WHITE); gravity = android.view.Gravity.CENTER; textSize = 14f })
        fun slider(label: String, min: Int, max: Int, key: String, default: Int, apply: (Int) -> Unit) {
            panel.addView(android.widget.TextView(this).apply { text = label; setTextColor(Color.WHITE); textSize = 12f })
            val seek = android.widget.SeekBar(this).apply { this.max = max-min; progress = getSharedPreferences("kiyan_settings", MODE_PRIVATE).getInt(key, default)-min; setOnSeekBarChangeListener(object: android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: android.widget.SeekBar?, value: Int, fromUser: Boolean) { val v=value+min; getSharedPreferences("kiyan_settings", MODE_PRIVATE).edit().putInt(key,v).apply(); apply(v) }
                override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}
                override fun onStopTrackingTouch(sb: android.widget.SeekBar?) {}
            }) }
            panel.addView(seek)
        }
        slider("ارتفاع اللوحة", 180, 360, "keyboard_height", 260) { h -> parent.layoutParams = parent.layoutParams.apply { height = (h * resources.displayMetrics.density).toInt() } }
        slider("حجم الحروف", 12, 28, "keyboard_font_size", 16) { size ->
            fun update(v: View) { if (v is Button && v.id !in listOf(R.id.tool_settings,R.id.tool_search)) v.textSize=size.toFloat(); if(v is android.view.ViewGroup) for(i in 0 until v.childCount) update(v.getChildAt(i)) }; update(parent)
        }
        val edit = Button(this).apply { text = "لوحة التحرير والأسهم"; setOnClickListener { showEditingPanel(root) } }
        panel.addView(edit)
        parent.addView(panel, 1)
    }

    private fun sendEditorKey(code: Int) {
        val ic = currentInputConnection ?: return
        ic.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, code))
        ic.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, code))
    }

    private fun showEditingPanel(root: View) {
        val parent = root as? LinearLayout ?: return
        parent.findViewWithTag<View>("kiyan_inline_panel")?.let { parent.removeView(it) }
        val panel = LinearLayout(this).apply { tag = "kiyan_inline_panel"; orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.rgb(20,55,105)); gravity = android.view.Gravity.CENTER }
        val actions = listOf("Del" to { currentInputConnection?.deleteSurroundingText(1,0) }, "←" to { sendEditorKey(android.view.KeyEvent.KEYCODE_DPAD_LEFT) }, "→" to { sendEditorKey(android.view.KeyEvent.KEYCODE_DPAD_RIGHT) }, "↑" to { sendEditorKey(android.view.KeyEvent.KEYCODE_DPAD_UP) }, "↓" to { sendEditorKey(android.view.KeyEvent.KEYCODE_DPAD_DOWN) }, "قص" to { currentInputConnection?.performContextMenuAction(android.R.id.cut) }, "نسخ" to { currentInputConnection?.performContextMenuAction(android.R.id.copy) }, "لصق" to { currentInputConnection?.performContextMenuAction(android.R.id.paste) })
        actions.forEach { (label, action) -> panel.addView(Button(this).apply { text=label; textSize=12f; setOnClickListener { action() } }, LinearLayout.LayoutParams(0, (44*resources.displayMetrics.density).toInt(), 1f)) }
        parent.addView(panel, 1)
    }

    private fun showCalculator() {
        val input = android.widget.EditText(this).apply { hint = "مثال: 12*4+3"; inputType = android.text.InputType.TYPE_CLASS_TEXT }
        android.app.AlertDialog.Builder(this).setTitle("الحاسبة السريعة").setView(input).setPositiveButton("احسب") { _, _ ->
            val expr = input.text.toString().replace(" ", "")
            val result = runCatching { evaluateBasic(expr) }.getOrNull()
            if (result != null) currentInputConnection?.commitText(result.toString(), 1) else toast("تحقق من العملية الحسابية")
        }.setNegativeButton("إلغاء", null).show()
    }

    private fun evaluateBasic(expr: String): Double {
        // Safe basic evaluator: supports + - * / and decimal numbers, no code execution.
        val tokens = Regex("[0-9]+(?:\\.[0-9]+)?|[+*/-]").findAll(expr).map { it.value }.toList()
        require(tokens.joinToString("") == expr && tokens.isNotEmpty())
        val values = mutableListOf<Double>(); val ops = mutableListOf<String>(); var i=0
        while(i<tokens.size) { val t=tokens[i]; if(t in listOf("+","-","*","/")) ops.add(t) else values.add(t.toDouble()); i++ }
        var j=0; while(j<ops.size) { if(ops[j]=="*" || ops[j]=="/") { if (ops[j]=="/") require(values[j+1] != 0.0); val v=if(ops[j]=="*") values[j]*values[j+1] else values[j]/values[j+1]; require(v.isFinite()); values[j]=v; values.removeAt(j+1); ops.removeAt(j) } else j++ }
        var result=values.first(); ops.forEachIndexed { index, op -> result=if(op=="+") result+values[index+1] else result-values[index+1] }; return result
    }

    private fun toast(message: String) = android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show()

    /** Called for ordinary text keys: text insertion is never conditional on sound. */
    fun onKeyPress(code: Int, char: Char) {
        val inputConnection: InputConnection? = currentInputConnection
        inputConnection?.commitText(char.toString(), 1)
        if (::pianoSoundManager.isInitialized) pianoSoundManager.playPianoNote(char)
        inputView?.let { updateSuggestions(it) }
    }

    /** Local, privacy-friendly phrase suggestions; this is not an online predictive model. */
    private fun updateSuggestions(root: View) {
        val before = currentInputConnection?.getTextBeforeCursor(100, 0)?.toString().orEmpty()
        val word = before.takeLastWhile { !it.isWhitespace() }.lowercase()
        val choices = when {
            word.isBlank() -> if (arabicMode) listOf("السلام عليكم", "شكراً لك", "😊") else listOf("Hello", "Thanks", "😊")
            arabicMode && (word.startsWith("سلا") || word == "سل") -> listOf("سلام", "السلام", "السلام عليكم")
            arabicMode && (word.startsWith("مر") || word == "م") -> listOf("مرحبا", "مرحباً", "مساء الخير")
            arabicMode && (word.startsWith("شك") || word == "ش") -> listOf("شكراً", "شكراً لك", "شكراً جزيلاً")
            arabicMode && word.startsWith("صباح") -> listOf("صباح الخير", "صباح النور", "صباح الورد")
            !arabicMode && (word.startsWith("hel") || word == "h") -> listOf("hello", "help", "hello there")
            !arabicMode && (word.startsWith("tha") || word == "t") -> listOf("thanks", "thank you", "that's")
            !arabicMode && word.startsWith("goo") -> listOf("good", "good morning", "good luck")
            else -> if (arabicMode) listOf("تمام", "إن شاء الله", "😊") else listOf("okay", "please", "😊")
        }
        val ids = intArrayOf(R.id.suggestion_1, R.id.suggestion_2, R.id.suggestion_3)
        ids.forEachIndexed { index, id ->
            root.findViewById<Button>(id)?.let { button ->
                button.text = choices.getOrElse(index) { "" }
                button.isEnabled = button.text.isNotBlank()
                button.alpha = if (button.isEnabled) 1f else 0.45f
            }
        }
    }

    override fun onDestroy() {
        if (::pianoSoundManager.isInitialized) pianoSoundManager.release()
        super.onDestroy()
    }
}
