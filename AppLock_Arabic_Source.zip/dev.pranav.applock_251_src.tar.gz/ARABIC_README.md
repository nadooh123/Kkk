# App Lock — Arabic localization (working source)

This source tree includes an Arabic resource set at `app/src/main/res/values-ar/strings.xml`.

## What changed
- Added Arabic translations for the app's onboarding, app list, lock/PIN/password flows, permissions, settings, security options, and dialogs.
- Kept resource names and format placeholders (such as `%1$s` and `%1$d`) aligned with the original resources.
- The manifest already declares `android:supportsRtl="true"`, so Android can apply RTL when Arabic is selected as the app/device language.

## Build status
The project has not been compiled in this environment: the archive does not include the `gradlew` launcher script, and a configured Android SDK/Gradle installation was not available. Open the project in Android Studio, install the required SDK for the project's `compileSdk`, then sync and build `:app:assembleDebug`.

## Notes
This is a source-code localization pass, not a signed APK. Test Arabic layout on a real device/emulator, especially Compose screens, long permission explanations, and dialogs. Some third-party/system-owned screens may remain in the device's language.
